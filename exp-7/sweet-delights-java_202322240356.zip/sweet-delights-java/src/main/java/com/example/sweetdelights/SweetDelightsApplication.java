// src/main/java/com/example/sweetdelights/SweetDelightsApplication.java
package com.example.sweetdelights;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SweetDelightsApplication {
    public static void main(String[] args) {
        SpringApplication.run(SweetDelightsApplication.class, args);
    }
}
